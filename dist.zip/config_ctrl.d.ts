/// <reference path="../node_modules/grafana-sdk-mocks/app/headers/common.d.ts" />
export default class SumoLogicMetricsConfigCtrl {
    static templateUrl: string;
    current: any;
    constructor($scope: any);
}
